from deepface import DeepFace
import os

# This function will compare a test image with all stored student images
def recognize_face(test_image_path, database_path="student_data/images"):
    try:
        result = DeepFace.find(
            img_path=test_image_path,
            db_path=database_path,
            enforce_detection=False
        )
        if result[0].shape[0] > 0:
            matched_file = result[0]['identity'].values[0]
            name = os.path.basename(matched_file).split('.')[0]
            return name
        else:
            return "Unknown"
    except Exception as e:
        return f"Error: {e}"

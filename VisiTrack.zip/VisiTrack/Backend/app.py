from flask import Flask, request, jsonify
from flask_cors import CORS
from deepface import DeepFace
import os
import json
import cv2
import uuid
from datetime import datetime

app = Flask(__name__)
CORS(app)

LOG_PATH = "logs.json"
KNOWN_DIR = "known_faces"

if not os.path.exists(LOG_PATH):
    with open(LOG_PATH, "w") as f:
        json.dump([], f)

# 📌 Load known embeddings from folders
def load_known_faces():
    known = []
    for person_dir in os.listdir(KNOWN_DIR):
        person_path = os.path.join(KNOWN_DIR, person_dir)
        if os.path.isdir(person_path):
            for img_name in os.listdir(person_path):
                img_path = os.path.join(person_path, img_name)
                known.append({"id": person_dir, "img_path": img_path})
    return known

@app.route("/visitor", methods=["POST"])
def recognize_face():
    file = request.files.get("image")
    if not file:
        return jsonify({"error": "No image uploaded"}), 400

    temp_filename = f"temp_{uuid.uuid4().hex}.jpg"
    file.save(temp_filename)

    known_faces = load_known_faces()
    found = False
    result = {}

    for face in known_faces:
        try:
            verified = DeepFace.verify(img1_path=temp_filename, img2_path=face["img_path"], enforce_detection=False)
            if verified["verified"]:
                name_roll = face["id"]
                found = True
                result = {
                    "name_roll": name_roll,
                    "verified": True,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                break
        except Exception as e:
            print("Verification error:", e)

    os.remove(temp_filename)

    if found:
        # ✅ Update log
        with open(LOG_PATH, "r+") as f:
            logs = json.load(f)
            logs.append(result)
            f.seek(0)
            json.dump(logs, f, indent=2)
        return jsonify(result)
    else:
        return jsonify({"verified": False, "message": "No match found"})

@app.route("/admin/login", methods=["POST"])
def login():
    data = request.get_json()
    if data.get("username") == "admin" and data.get("password") == "admin123":
        return jsonify({"success": True})
    return jsonify({"success": False})

@app.route("/admin/logs", methods=["GET"])
def get_logs():
    with open(LOG_PATH) as f:
        logs = json.load(f)
    return jsonify(logs)

if __name__ == "__main__":
    app.run(debug=True)
